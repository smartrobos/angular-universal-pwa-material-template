export const environment = {
  production: true,
  "HOST": "http://localhost:4200/",
  "BACK_END_HOST" : "http://localhost:3000/",
  "BACK_END_HOST1" : "https://backend.goshortify.com/"
};
