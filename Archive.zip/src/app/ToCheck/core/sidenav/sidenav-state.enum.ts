export enum SidenavState {
  Expanded = 'expanded',
  ExpandedClosed= 'expandedClosed',
  Collapsed = 'collapsed',
  CollapsedHover = 'collapsedHover',
  Mobile = 'mobile',
  MobileOpen = 'mobileOpen'
}
