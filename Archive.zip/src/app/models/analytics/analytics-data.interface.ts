export interface HomePageAnalyticsData {
  count: number,
  type : string
}
