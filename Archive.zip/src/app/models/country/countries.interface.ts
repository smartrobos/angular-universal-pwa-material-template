export interface countriesData{
    country:string
}