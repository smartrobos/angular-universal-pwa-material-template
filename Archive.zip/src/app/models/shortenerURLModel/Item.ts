export interface Item {
  createdAt: string;
  customName: string;
  email: string;
  updatedAt: string;
  url: string;
  urlType: string;
  userType: string;
}
