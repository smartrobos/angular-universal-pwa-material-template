export interface Item {
    id: any;
    uniqueItems: Array<string>;
}
